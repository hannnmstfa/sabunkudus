<?php

$conn=mysqli_connect('localhost','root','','topup');
if(!$conn){
	echo 'gagal terhubung';
}
?>